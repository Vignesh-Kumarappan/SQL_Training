import { NgModule } from "@angular/core";
import { FirstComponent } from "./FirstComponent";

@NgModule({
    declarations:[FirstComponent],
    imports:[],
    exports:[FirstComponent]
})

export class MyModule{}