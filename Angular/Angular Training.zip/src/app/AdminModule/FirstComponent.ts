import { Component } from "@angular/core";

@Component({
    selector:'f-com',
    template: `<div>
    <h1> My First Module </h1>
    </div>
    `
})

export class FirstComponent{
    
}