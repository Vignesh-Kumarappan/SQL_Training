export class Products {
    name: string;
    price: number;
    image: string;
    
    constructor(public n: string, public p: number, public img:string){
        this.name = n;
        this.price = p;
        this.image = img;
    }
}