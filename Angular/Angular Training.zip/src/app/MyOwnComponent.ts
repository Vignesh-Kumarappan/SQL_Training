import { Component } from "@angular/core";
import {Products} from "./Products";
@Component({
    selector: "my-own-com",
    template: `
        
        <h1>Products</h1>
        <br/>
        <br/>
        <div>
          <ul *ngFor="let n of prod">
              <h3>{{n.name}} || Cost - Rs.{{n.price}}</h3> <img src="/assets/Images/{{n.image}}">
          </ul>
        </div>         
       `
})

export class MyOwnComponent {
  prod = [
    new Products ("Pen",50,'pen.jpg'), 
    new Products ("Pencil",10,'Pencil.jpg')
];
}