import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormValidation } from './FormValidation';
import { MyFormExample } from './MyFormExample';

const routes: Routes = [
  { path: 'TemplateForm', component: MyFormExample},
  { path: 'ModelForm', component: FormValidation}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
