import { Component } from "@angular/core";

@Component({
    selector:'product-form',
    templateUrl:'./product-form.html'
})

export class productForm{
    pId!:number
    pName!:string
    pPrice!:number
    onSubmit(value:any){
        this.pId = value.t1;
        this.pName = value.t2;
        this.pPrice = value.t3
        console.log(value);
    }
}