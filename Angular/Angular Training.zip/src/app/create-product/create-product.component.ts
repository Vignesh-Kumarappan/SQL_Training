import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { ProductsService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {

  product: Product = new Product();
  submitted=false;

  constructor(private proService:ProductsService/*, private router:Router*/) { }

  ngOnInit(): void {
  }

  newProduct():void{
    this.submitted = false;
    this.product = new Product();
  }

  addSave(){
    this.proService.createProduct(this.product).subscribe(data=>console.log(data),error=>console.log(error));
    this.product = new Product();
    //this.gotoList();
  }

  onSubmit(){
    this.submitted=true;
    this.addSave();
  }

  /*
  gotoList(){
    this.router.navigate(['/products'])
  }
  */

}
