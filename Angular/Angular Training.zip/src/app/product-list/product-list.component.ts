import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../product.service';
import { Observable } from 'rxjs';
import { Product } from '../Product';
//import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  product!: Observable<Product[]>;

  constructor(private proService:ProductsService , /*private router:Router*/) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.product=this.proService.getProductList();
  }

}
