export class Product{
    pID!:number;
    pName!:string;
    pPrice!:number;
}