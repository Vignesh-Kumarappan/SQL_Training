import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MyComponent } from './MyComponent';
import { MyOwnComponent } from './MyOwnComponent';
import { CustomDirectiveExample } from './CustomDirectiveExample';

import { AppComponent } from './app.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { IfexampleComponent } from './ifexample/ifexample.component';
import { PipeExampleComponent } from './pipe-example/pipe-example.component';
import { SortPipe } from './CustomSortPipe';
import { MyServiceComponent } from './MyServiceComponent';
import {HttpClientModule} from '@angular/common/http';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { MyFormExample } from './MyFormExample';
import { productForm } from './productForm';
import { CreateProductComponent } from './create-product/create-product.component';
import { FormValidation } from './FormValidation';
import { MyModule } from './AdminModule/MyModule';
import { AppRoutingModule } from './app-routing.module';


@NgModule({
  declarations: [
    AppComponent,PipeExampleComponent,SortPipe,
    MyComponent,
    MyOwnComponent,
    CustomDirectiveExample,
    IfexampleComponent,
    PipeExampleComponent,
    MyServiceComponent, 
    EmployeeDetailsComponent, ProductListComponent, MyFormExample, productForm, 
    CreateProductComponent,FormValidation
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule,AppRoutingModule,MyModule
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
