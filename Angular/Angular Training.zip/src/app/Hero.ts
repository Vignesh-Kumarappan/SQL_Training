export class Hero {
    name: string;
    id: number;
    constructor(public i: number, public n: string){
        this.id = i;
        this.name = n;
    }
}