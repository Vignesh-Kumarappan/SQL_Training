import { Component } from "@angular/core";

@Component({
    selector:'my-form',
    templateUrl:'./my-form.html'
})

export class MyFormExample{
    name!:string
    pword!:string
    onSubmit(value:any){
        this.name = value.t1;
        this.pword = value.t2;
        console.log(value);
    }
}