import { Component } from "@angular/core";
import {Hero} from "./Hero";
import {Students} from "./Students";
@Component({
    selector: "my-com",
    template: `
    <div>     
        <div>
           <h1>Welcome to {{name}}, Vignesh</h1>
           <ul *ngFor="let n of names">
              <li> {{ n }} </li>
           </ul>
         </div>
         <br/>
         <h3>Heros</h3>
         <div>
           <ul *ngFor="let s of heros">
             <li> {{s.id}} {{s.name}} </li>
           </ul>
         </div> 
         <br/>
         <h3>Students</h3>
         <div>
           <ul *ngFor="let m of stud">
             <li> {{m.id}} {{m.name}} {{m.marks}}</li>
           </ul>
         </div> 

    <div>
    `
})

export class MyComponent {
   name: string = "Sonata";
   names: string[] = ["abc","xyz"];

   heros = [
    new Hero (1,"Ganesh"), 
    new Hero(2,"Hari")
];

stud = [
    new Students (1,"Vicky", 80), 
    new Students (2,"Vamsi", 90)
];
}
