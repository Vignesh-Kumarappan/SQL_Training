import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
    providedIn:'root'
})

export class ProductsService{
    private baseUrl='https://localhost:44319/api/Products';

    constructor(private httpClient:HttpClient){

    }
    getProductList():Observable<any>{
        return this.httpClient.get(this.baseUrl);
    }

    createProduct(product:Object):Observable<Object>{
        return this.httpClient.post(this.baseUrl,product);
    }
}