import { Component } from "@angular/core";
import { MyService } from "./MyService";

@Component({
    selector:'my-ser-com',
    template:`
    <div>
    <h1> My Name is {{name}}</h1>
    </div>
    `,
    providers:[MyService]
})

export class MyServiceComponent{
    name:string
    constructor(private my:MyService){
        this.name = my.getName();
    }
}