using Microsoft.VisualStudio.TestTools.UnitTesting;
using MokAssesment_Question_3;

namespace Book_Author_Testing
{
    [TestClass]
    public class UnitTest1
    {
        Book b;
        [TestInitialize]
        public void InitValues()
        {
            b = new Book("C#", new Author[] { new Author("Alex", "alex@ssl.com", 'm') }, 19.95, 99);
        }

        [TestMethod]
        public void Test_getAuthors()
        {
            //Arrange
            int expectednofauthors = 1;

            //Act
            int actual = b.getAuthorsDetail().Length;

            //Assert
            Assert.AreEqual(expectednofauthors, actual, "Method does not return the count correctly..");
        }

    }


}
