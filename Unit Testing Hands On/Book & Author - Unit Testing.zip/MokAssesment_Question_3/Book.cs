﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MokAssesment_Question_3
{
    public class Book
    {
        string name;
        Author[] author;
        double price;
        int qty = 0;
        public Book(string name, Author[] author, double price, int qty)
        {
            this.name = name;
            this.author = author;
            SetPrice(price);
            SetQty(qty);

        }

        public Book(string name, Author[] author, double price)
        {
            this.name = name;
            this.author = author;
            SetPrice(price);

        }

        public string GetName()
        {
            return name;
        }

        public double GetPrice()
        {
            return price;
        }

        //public Author GetAuthor()
        //{
        //    return author;
        //}

        public int GetQty()
        {
            return qty ;
        }


        public void SetPrice(double p)
        {
            this.price = p;
        }

        public void SetQty(int q)
        {
            this.qty = q;
        }

        public Author[] getAuthorsDetail()
        {
            return author;
        }

        public string getAuthors()
        {
            string result = "";
            foreach (Author a in author)
                result += a.ToString();
            return result;
        }
        public override string ToString()
        {
            return $"Book[name={name},{getAuthors()},price={price},qty={qty}";
        }
    }

    class TestBook
    {
        public static void Main()
        {

            //Author a = new Author("Vignesh", "vignesx@ssl.com", 'm'); 

            //Book dummyBook = new Book("C#", a, 19.95, 99);  // Test Book's Constructor
            //Console.WriteLine(dummyBook);

            //Console.WriteLine(dummyBook.GetAuthor().ToString());

            Book dummyBook = new Book("C#", new Author[] { new Author("Alex", "alex@ssl.com", 'm') }, 19.95, 99);
            Console.WriteLine(dummyBook);
        }
    }
}
