﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Collections_Exercise
{

    /// <summary>
    /// Sorting list<int>
    /// </summary>

    class OuptputListRemoveOddOuccurance
    {
        public static void Main()
        {
            List<int> Sequence = new List<int>();
            Console.WriteLine("Enter Sequence of numbers");
            string i = Console.ReadLine();

            while (i != "")
            {

                int number = int.Parse(i);
                Sequence.Add(number);
                i = Console.ReadLine();
            }
            
                for (int x = 0; x < Sequence.Count(); x++)
                {
                int count = 0;
                for (int y = 0; y < Sequence.Count(); y++)
                {
                    if (Sequence[x] == Sequence[y])
                        count++;
                }
                if (count % 2 == 0)
                    Console.WriteLine(Sequence[x]);
            }
        }
    }
}