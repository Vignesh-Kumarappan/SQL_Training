﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Collections_Exercise
{
    
    /// <summary>
    /// Sum and Average of number in list<int>
    /// </summary>
    
    class OuptputListSumAverage
    {
        public static void Main()
        {
            List<int> Sequence = new List<int>();
            Console.WriteLine("Enter Sequence of numbers");
            string i = Console.ReadLine();
            
            while (i != "")
            {
                
                int number = int.Parse(i);
                try
                {
                    if(number<0)
                        Console.WriteLine("Invalid Input, Enter only Positive Integers");
                    else
                        Sequence.Add(number);
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                
                i = Console.ReadLine();
            }

            //for (int k = 0; k < Sequence.Count; k++)
            //   Console.Write($"{Sequence[k]}, ");

            Console.WriteLine($"The sum of sequence - {Sequence.Sum()}");
            Console.WriteLine($"The avg of sequence - {Sequence.Average()}");
        }
    }
}
