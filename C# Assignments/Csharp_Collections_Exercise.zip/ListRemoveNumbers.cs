﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Collections_Exercise
{

    /// <summary>
    /// Removing negative numbers in list<int>
    /// </summary>

    class OuptputListRemoveNumbers
    {
        public static void Main()
        {
            List<int> Sequence = new List<int>();
            Console.WriteLine("Enter Sequence of numbers");
            string i = Console.ReadLine();

            while (i != "")
            {

                int number = int.Parse(i);
                Sequence.Add(number);
                i = Console.ReadLine();
            }

            Console.WriteLine("Original sequence");
            Console.WriteLine(String.Join("\n", Sequence));

            for (int k = 0; k < Sequence.Count; k++)
                if (Sequence.ElementAt(k) < 0)
                {
                    Sequence.RemoveAt(k);
                    k--;
                }
           

            Console.WriteLine("Sequence with positive numbers ");
            Console.WriteLine(String.Join("\n", Sequence));


        }
    }
}