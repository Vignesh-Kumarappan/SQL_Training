﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Collections_Exercise
{

    /// <summary>
    /// Reversing stack<int>
    /// </summary>

    class OuptputStackReverse
    {
        public static void Main()
        {
            Stack<int> Seq = new Stack<int>();

            Console.WriteLine("Enter Sequence of numbers");
            string i = Console.ReadLine();

            while (i != "")
            {

                int number = int.Parse(i);
                Seq.Push(number);
                i = Console.ReadLine();
            }
            Console.WriteLine("Reversed Sequence");

            while(Seq.Count() != 0)
            {
                Console.WriteLine(Seq.Pop());
            }

        }
    }
}