﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Exercise
{
    class Dimension
    {
        public double x { get; set; }
        public double y { get; set; }


        public Dimension(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public virtual double Area()
        {
            return 0;
        }
    }

    class circle : Dimension 
    {

        public circle(double x, double y) :base(x,y)
        {

        }
        public override double Area()
        {
            return Math.Round(Math.PI * x * y,2);      // Assuming x=y=Radious with (x,y) as center of circle
        }

    }

    class cylinder : Dimension
    {

        public cylinder(double x, double y) : base(x, y)
        {

        }
        public override double Area()
        {
            return Math.Round(2*Math.PI * x * (x + 2*y), 2);      // Assuming x=Radious & y as half height od cylinder with (x,y) as center of cylinder
        }
    }

    class sphere : Dimension
    {

        public sphere(double x, double y) : base(x, y)
        {

        }
        public override double Area()
        {
            return Math.Round(4 * Math.PI * x * y, 2);      // Assuming x=y=Radious with (x,y) as center of sphere
        }
    }

    class OputputAreaOfShapes
    {
        public static void Main()
        {
            circle c = new circle(1, 1);
            Console.WriteLine($"Area of Circle is {c.Area()}");

            cylinder cy = new cylinder(1, 1);
            Console.WriteLine($"Area of Cylinder is {cy.Area()}");

            sphere s = new sphere(1, 1);
            Console.WriteLine($"Area of Sphere is {s.Area()}");

        }
    }
}
