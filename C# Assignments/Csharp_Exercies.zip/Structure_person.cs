﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Exercise
{

    public struct Person
    {       
        public string Name;
        public string gender;
        public int Height;
        public int Weight;

    }

    class OutputStructure_person
    {
        public static void Main()
        {
            Person p;

            Console.Write("Enter Name :");
            string Name = Console.ReadLine();
            p.Name = Name;

            Console.Write("Enter Gender :");
            string Gender = Console.ReadLine();
            p.gender = Gender;

            Console.Write("Enter Height :");
            int Height = int.Parse(Console.ReadLine());
            p.Height = Height;

            Console.Write("Enter Weight :");
            int Weight = int.Parse(Console.ReadLine());
            p.Weight = Weight;

            Console.WriteLine($@" 
                                  Name - {p.Name}
                                  Gender - {p.gender}
                                  Height - {p.Height}
                                  Weight - {p.Weight}"); 
                           

        }
    }
}
