﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Exercise
{
    public interface Car
    {
        string input(string name);
        string output();

    }

    class Interface : Car
    {
        public string input(string name)
        {
            return $"car name - {name}";
        }
        public string output()
        {
            return $"Price is xxx";
        }
    }

    class OutputInterface
    {
        public static void Main()
        {
            Interface i = new Interface();
            Console.WriteLine(i.input("Audi"));
            Console.WriteLine(i.output());

        }
    }
    
}
