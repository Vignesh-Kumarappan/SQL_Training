﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Exercise
{
    
    class Student
    {
        public string RegisterNo { get; set; }
        public string Name { get; set; }

        public Student(string Name, string RegisterNo)
        {
            this.Name = Name;
            this.RegisterNo = RegisterNo;
        }
        public override string ToString()
        {
            return $"Name of the student is {Name} and Register No. is {RegisterNo}";
        }
    }

    class Science : Student
    {
        double phy;
        double chem;
        double maths;
        double Avg;
        public Science(string Name, string RegisterNo, double phy, double chem, double maths) : base(Name, RegisterNo)
        {
            this.phy = phy;
            this.chem = chem;
            this.maths = maths;
        }

        double Average()
        {
            double sum = maths + phy + chem;
            Avg = sum / 3;
            return Avg;
        }
        public override string ToString()
        {
            return $@"{Name} with register no. {RegisterNo} of Science branch has scored
                    {phy} in Physics
                    {chem} in Chemistry
                    {maths} in Maths
             His average score is {Average()}";
        }
    }

    class Commerce : Student
    {
            double Economics;
            double Accounts;
            double Bank;
            double Avg;
            public Commerce(string Name, string RegisterNo, double Economics, double Accounts, double Bank) : base(Name, RegisterNo)
            {
                this.Economics = Economics;
                this.Accounts = Accounts;
                this.Bank = Bank;
            }

            double Average()
            {
                double sum = Economics + Accounts + Bank;
                Avg = sum / 3;
                return Avg;
            }

            public override string ToString()
            {
                return $@"{Name} with register no. {RegisterNo} of Commerce branch has scored
                    {Economics} in Economics
                    {Accounts} in Accounts
                    {Bank} in Banking
             His average score is {Average()}";

            }

    }

    class OutputStudent
    {
        public static void Main()
        {
                Science s = new Science("1", "xxx", 95, 95, 95);
                Commerce c = new Commerce("2", "yyy", 90, 90, 90);
                Console.WriteLine(s.ToString());
                Console.WriteLine(c.ToString());
         }
       
    }


}
